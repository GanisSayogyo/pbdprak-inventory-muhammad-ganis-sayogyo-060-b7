<?php
// penjualan.php
include "database.php";
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$username = $_SESSION['username'] ?? '';

$db = new databaseconnection();
$db->get_connection();

// ambil list penjualan (header) untuk tabel atas
$q = "SELECT * FROM V_PENJUALAN ORDER BY id_penjualan DESC";
$penjualan = $db->send_query($q);

// ambil barang untuk dropdown (tampilkan nama + harga)
$barangList = $db->send_query("SELECT id_barang, nama, harga FROM barang WHERE status = 1")['data'] ?? [];

// ambil keranjang user (otomatis dari session)
$keranjang = [];
if ($id_user) {
    $kr = $db->send_query("SELECT k.*, b.nama, b.harga
                           FROM keranjang_penjualan k
                           JOIN barang b ON k.id_barang = b.id_barang
                           WHERE k.id_user = $id_user
                           ORDER BY k.created_at ASC");
    if ($kr['status'] === 'success') $keranjang = $kr['data'];
}

$db->exit_connection();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Manajemen Penjualan — Elegan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root{--bg:#efefef;--card:#f6f6f6;--muted:#6c757d;--accent:#6c6f73;}
    body{background:var(--bg);font-family:"Inter",system-ui;}
    .card-custom{background:var(--card);border:0;box-shadow:0 6px 18px rgba(21,24,28,0.06);border-radius:12px;}
    .page-title{font-weight:700;color:#2b2d2f;}
    .small-muted{color:var(--muted);font-size:.9rem;}
    .btn-primary{background:#5f6366;border-color:#5f6366;}
    .btn-primary:hover{background:#4f5153;border-color:#4f5153;}
  </style>
</head>
<body>
<div class="container py-5">

  <!-- HEADER -->
  <div class="d-flex justify-content-between mb-4 align-items-center">
    <div>
      <h1 class="page-title mb-0">Manajemen Penjualan</h1>
      <div class="small-muted">Tambah, keranjang, checkout, dan lihat daftar penjualan</div>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">Back Home</a>
  </div>

  <!-- TABEL PENJUALAN -->
  <div class="card card-custom mb-4">
    <div class="card-body">
      <h5 class="mb-3">Daftar Penjualan</h5>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>#</th><th>ID Penjualan</th><th>Tanggal</th><th>Subtotal</th><th>PPN</th><th>Total</th><th>User</th><th>Margin %</th><th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($penjualan['status'] !== 'success' || count($penjualan['data'])===0): ?>
              <tr><td colspan="9" class="text-center small-muted py-4">Belum ada data penjualan</td></tr>
            <?php else: $no=1; foreach($penjualan['data'] as $p): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($p['id_penjualan']); ?></td>
                <td><?= htmlspecialchars($p['created_at']); ?></td>
                <td><?= number_format($p['subtotal_nilai'] ?? 0); ?></td>
                <td><?= number_format($p['ppn'] ?? 0); ?></td>
                <td><?= number_format($p['total_nilai'] ?? 0); ?></td>
                <td><?= htmlspecialchars($p['USERNAME'] ?? '-'); ?></td>
                <td><?= htmlspecialchars($p['margin_persen'] ?? '-'); ?></td>
                <td>
                  <a href="penjualan_detail.php?id=<?= $p['id_penjualan']; ?>" class="btn btn-sm btn-outline-primary">Detail</a>
                </td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- FORM TAMBAH KE KERANJANG & TAMPIL KERANJANG -->
  <div class="row">
    <div class="col-md-6">
      <div class="card card-custom mb-4">
        <div class="card-body">
          <h5 class="mb-3">Tambah ke Keranjang</h5>

          <form method="POST" action="keranjang_action.php">
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="id_user" value="<?= $id_user; ?>">
            
            <div class="mb-3">
              <label class="form-label">User</label>
              <input type="text" class="form-control" value="<?= htmlspecialchars($username); ?>" disabled>
            </div>

            <div class="mb-3">
              <label class="form-label">Barang</label>
              <select name="id_barang" id="id_barang" class="form-control" required onchange="syncHargaStock()">
                <option value="">-- Pilih Barang --</option>
                <?php foreach($barangList as $b): ?>
                  <option value="<?= $b['id_barang']; ?>" data-harga="<?= $b['harga']; ?>">
                    <?= htmlspecialchars($b['nama']); ?> — <?= number_format($b['harga']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="row g-2">
              <div class="col-6">
                <label class="form-label">Jumlah</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control" min="1" value="1" required>
              </div>
              <div class="col-6">
                <label class="form-label">Harga Satuan</label>
                <input type="number" id="harga_view" class="form-control" readonly>
              </div>
            </div>

            <div class="mt-3">
              <button class="btn btn-primary">Tambah ke Keranjang</button>
            </div>
          </form>

        </div>
      </div>
    </div>

    <!-- KERANJANG -->
    <div class="col-md-6">
      <div class="card card-custom mb-4">
        <div class="card-body">
          <h5 class="mb-3">Keranjang (User: <?= htmlspecialchars($username); ?>)</h5>

          <div class="table-responsive">
            <table class="table table-sm">
              <thead><tr><th>#</th><th>Barang</th><th>Jumlah</th><th>Harga</th><th>Subtotal</th><th>Aksi</th></tr></thead>
              <tbody>
                <?php if (empty($keranjang)): ?>
                  <tr><td colspan="6" class="text-center small-muted py-4">Keranjang kosong</td></tr>
                <?php else: $i=1; $totalKeranjang=0; foreach($keranjang as $k): 
                    $sub = ($k['harga'] * $k['jumlah']);
                    $totalKeranjang += $sub;
                ?>
                  <tr>
                    <td><?= $i++; ?></td>
                    <td><?= htmlspecialchars($k['nama']); ?></td>
                    <td><?= $k['jumlah']; ?></td>
                    <td><?= number_format($k['harga']); ?></td>
                    <td><?= number_format($sub); ?></td>
                    <td>
                      <form method="POST" action="keranjang_action.php" style="display:inline">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="id_keranjang" value="<?= $k['id_keranjang']; ?>">
                        <button class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus item?')">Hapus</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
                <tr>
                  <td colspan="4" class="text-end"><strong>Total Keranjang</strong></td>
                  <td><strong><?= number_format($totalKeranjang); ?></strong></td>
                  <td></td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <div class="d-flex justify-content-between">
            <a href="keranjang_action.php?action=clear" class="btn btn-outline-secondary"
               onclick="return confirm('Kosongkan keranjang?')">Kosongkan</a>

            <?php if (!empty($keranjang)): ?>
              <!-- Checkout -->
              <form method="POST" action="checkout.php">
                <input type="hidden" name="id_user" value="<?= $id_user; ?>">
                <button class="btn btn-success">Checkout (Buat Penjualan)</button>
              </form>
            <?php else: ?>
              <button class="btn btn-success" disabled>Checkout</button>
            <?php endif; ?>
          </div>

        </div>
      </div>
    </div>
  </div>

</div>

<script>
function syncHargaStock(){
  const sel = document.getElementById('id_barang');
  const harga = sel.options[sel.selectedIndex].dataset.harga || 0;
  document.getElementById('harga_view').value = harga;
}
document.addEventListener('DOMContentLoaded', function(){ syncHargaStock(); });
</script>
</body>
</html>
