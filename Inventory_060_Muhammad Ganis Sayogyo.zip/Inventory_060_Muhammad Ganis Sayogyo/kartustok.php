<?php
include "database.php";

$db = new databaseconnection();
$db->get_connection();

$query = "SELECT * FROM V_KARTU_STOK_DETAIL ORDER BY CREATED_AT ASC";
$hasil = $db->send_query($query);
?>

<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kartu Stok Barang</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root { --bg:#efefef; --card:#fff; --muted:#6c757d; }
    body { background:var(--bg); font-family:"Inter",system-ui; }
    .card-custom { background:var(--card); border:0; box-shadow:0 6px 18px rgba(21,24,28,0.06); border-radius:12px; }
    .page-title { font-weight:700; color:#2b2d2f; }
    .small-muted { color:var(--muted); font-size:.9rem; }
  </style>
</head>

<body>
<div class="container py-5">

  <!-- HEADER -->
  <div class="d-flex justify-content-between mb-4 align-items-center">
      <div>
          <h1 class="page-title mb-0 Barang</h1>
          <div class="small-muted">Riwayat pergerakan stok masuk & keluar</div>
      </div>
      <a href="index.php" class="btn btn-outline-secondary">Kembali</a>
  </div>

  <!-- CARD -->
  <div class="card card-custom">
    <div class="card-body">

      <?php if ($hasil["status"] !== "success" || count($hasil["data"]) == 0): ?>
        <div class="alert alert-warning">Belum ada data kartu stok.</div>
      <?php else: ?>
      
      <div class="table-responsive">
        <table class="table table-hover align-middle table-striped">
          <thead class="table-dark">
            <tr>
              <th>No</th>
              <th>Nama Barang</th>
              <th>Satuan</th>
              <th>Jenis Transaksi</th>
              <th class="text-end">Masuk</th>
              <th class="text-end">Keluar</th>
              <th class="text-end">Stok Akhir</th>
              <th>Tanggal</th>
            </tr>
          </thead>

          <tbody>
            <?php 
            $no = 1;
            foreach($hasil['data'] as $row): ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['NAMA_BARANG']); ?></td>
                <td><?= htmlspecialchars($row['NAMA_SATUAN']); ?></td>

                <td>
                  <?php if ($row['JENIS_TRANSAKSI'] == 'M'): ?>
                    <span class="badge bg-success">Masuk</span>
                  <?php else: ?>
                    <span class="badge bg-danger">Keluar</span>
                  <?php endif; ?>
                </td>

                <td class="text-end"><?= number_format($row['MASUK']); ?></td>
                <td class="text-end"><?= number_format($row['KELUAR']); ?></td>
                <td class="text-end fw-bold"><?= number_format($row['STOCK']); ?></td>
                <td><?= $row['CREATED_AT']; ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>

        </table>
      </div>

      <?php endif; ?>
    </div>
  </div>

</div>
</body>
</html>
