<?php
// satuan.php — tema abu-abu elegan
include "database.php";

$db = new databaseconnection();
$db->get_connection();

// Ambil data satuan
$query = "SELECT * FROM SATUAN ORDER BY ID_SATUAN ASC";
$result = $db->send_query($query);

// proses insert
$insertError = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nama'], $_POST['status'])) {
        $nama_raw = $_POST['nama'];
        $status_raw = $_POST['status'];

        $nama = trim($db->escape_string($nama_raw));
        $status = (int)$status_raw;

        if ($nama === '') {
            $insertError = "Nama satuan tidak boleh kosong.";
        } else {
            $insert = "INSERT INTO SATUAN (NAMA_SATUAN, STATUS)
                       VALUES ('".$nama."', ".$status.")";

            $resIns = $db->send_query($insert);

            if ($resIns['status'] === 'success') {
                header("Location: satuan.php");
                exit;
            } else {
                $insertError = "Gagal menambah satuan: " . $resIns['message'];
            }
        }
    }
}

$db->exit_connection();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Manajemen Satuan — Elegan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root{
      --bg: #efefef;
      --card: #f6f6f6;
      --muted: #6c757d;
      --accent: #6c6f73;
    }
    body { background: var(--bg); color: #222; font-family: "Inter", system-ui; }
    .card-custom{ background: var(--card); border: 0; box-shadow: 0 6px 18px rgba(21,24,28,0.06); border-radius: 12px; }
    .table thead th { background: transparent; color: var(--accent); border-bottom: 2px solid rgba(0,0,0,0.06); }
    .form-label { color: var(--muted); font-weight: 600; font-size: .9rem; }
    .btn-primary { background: #5f6366; border-color: #5f6366; }
    .btn-primary:hover { background:#4f5153; border-color:#4f5153; }
    .page-title { color: #2b2d2f; font-weight:700; }
    .small-muted { color: var(--muted); font-size: .9rem; }
    .table tbody tr:hover { background: #fbfbfb; }
    footer { margin-top: 32px; color: var(--muted); font-size: .9rem; text-align:center; }
  </style>
</head>
<body>
  <div class="container py-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="page-title mb-0">Manajemen Satuan</h1>
        <div class="small-muted">Tambah, edit, dan hapus data satuan</div>
      </div>
      <a href="index.php" class="btn btn-outline-secondary">Back Home</a>
    </div>

    <!-- FORM TAMBAH -->
    <div class="card card-custom mb-4">
      <div class="card-body">
        <h5 class="mb-3">Tambah Satuan</h5>

        <?php if ($insertError): ?>
          <div class="alert alert-danger py-2"><?php echo htmlspecialchars($insertError); ?></div>
        <?php endif; ?>

        <form method="POST" action="satuan.php">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama Satuan</label>
              <input type="text" name="nama" class="form-control" placeholder="PCS / BOX / KG" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-control">
                <option value="1">Aktif</option>
                <option value="0">Non Aktif</option>
              </select>
            </div>
          </div>

          <div class="mt-3">
            <button type="submit" class="btn btn-primary">Tambah</button>
            <button type="reset" class="btn btn-outline-secondary">Reset</button>
          </div>
        </form>
      </div>
    </div>

    <!-- TABEL LIST -->
    <div class="card card-custom">
      <div class="card-body">
        <h5 class="mb-3">Daftar Satuan</h5>

        <?php
        $rows = [];
        if (!isset($result) || !is_array($result)) {
            echo "<div class='alert alert-warning'>Gagal mengambil data satuan.</div>";
        } elseif ($result['status'] === 'error') {
            echo "<div class='alert alert-danger'>Query error: ".htmlspecialchars($result['message'])."</div>";
        } else {
            $rows = $result['data'] ?? [];
        }
        ?>

        <div class="table-responsive">
          <table class="table align-middle">
            <thead>
              <tr>
                <th style="width:6%">#</th>
                <th>ID</th>
                <th>Nama Satuan</th>
                <th>Status</th>
                <th class="text-center">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if (count($rows) === 0): ?>
                <tr><td colspan="5" class="text-center small-muted py-4">Belum ada data satuan</td></tr>
              <?php else: ?>
                <?php $no = 1; foreach ($rows as $r): ?>
                  <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($r['ID_SATUAN']); ?></td>
                    <td><?php echo htmlspecialchars($r['NAMA_SATUAN']); ?></td>
                    <td>
                      <?php echo ($r['STATUS'] == 1 ? "Aktif" : "Non Aktif"); ?>
                    </td>
                    <td class="text-center">
                      <a href="edit_satuan.php?id=<?php echo $r['ID_SATUAN']; ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                      <a href="hapus_satuan.php?id=<?php echo $r['ID_SATUAN']; ?>" class="btn btn-sm btn-outline-danger"
                         onclick="return confirm('Yakin hapus satuan ini?');">Hapus</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>

    <footer>
      &copy; <?php echo date('Y'); ?> Inventory System — Tema: Abu-abu Elegan
    </footer>

  </div>
</body>
</html>
