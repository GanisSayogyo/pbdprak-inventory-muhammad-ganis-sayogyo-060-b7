<?php
include "database.php";
session_start();

$db = new databaseconnection();
$db->get_connection();

$username = $db->escape_string($_POST['username']);
$password = $_POST['password'];

$query = "SELECT user.id_user, user.username, user.password, role.nama_role
          FROM user 
          JOIN role ON user.id_role = role.id_role
          WHERE user.username = '$username'";

$result = $db->send_query($query);

// cek data
if ($result['status'] === "success" && count($result['data']) > 0) {
    $row = $result['data'][0]; // ambil baris pertama

    if ($password === $row['password']) {
        $_SESSION['id_user']  = $row['id_user'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['role']     = $row['nama_role'];

        header("Location: index.php");
        exit();
    }
}

// gagal login
header("Location: login.php?error=1");
exit();
