<?php
require "database.php";

if (!isset($_GET['id'])) {
    die("ID pengadaan tidak ditemukan.");
}

$id = intval($_GET['id']);

$db = new databaseconnection();
$db->get_connection();

// hapus detail dulu (kalau ada tabel detail)
$db->send_query("DELETE FROM DETAIL_PENGADAAN WHERE ID_PENGADAAN = $id");

// hapus pengadaan utama
$del = $db->send_query("DELETE FROM PENGADAAN WHERE ID_PENGADAAN = $id");

$db->exit_connection();

header("Location: pengadaan.php");
exit;
