<?php
include "database.php";

if (!isset($_GET['id'])) {
    die("ID Penjualan tidak ditemukan.");
}

$id = $_GET['id'];

$db = new databaseconnection();
$conn = $db->get_connection();

/* =============================
   1. AMBIL DATA PENJUALAN
   ============================= */
$sql_penjualan = "CALL sp_get_penjualan_by_id($id)";
$penjualan = $db->send_query($sql_penjualan)['data'][0];

/* =============================
   2. AMBIL DETAIL BARANG
   ============================= */
$sql_detail = "
    SELECT d.*, b.NAMA AS NAMA_BARANG
    FROM DETAIL_PENJUALAN d
    JOIN BARANG b ON d.ID_BARANG = b.ID_BARANG
    WHERE d.ID_PENJUALAN = '$id'
";
$detail = $db->send_query($sql_detail)['data'];

$db->exit_connection();
?>

<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Detail Penjualan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #efefef; font-family: Inter, system-ui; }
    .card-custom { background:#fff; border:0; border-radius:14px; box-shadow:0 4px 20px rgba(0,0,0,.08); }
    .page-title { font-weight:700; }
    .muted { color:#6c757d; }
    th { color:#6c6f73; font-weight:600; }
  </style>
</head>

<body>
<div class="container py-5">

    <div class="mb-4">
        <h1 class="page-title">Detail Penjualan</h1>
        <div class="muted">ID Penjualan: <?= $penjualan['ID_PENJUALAN']; ?></div>
    </div>

    <a href="penjualan.php" class="btn btn-outline-secondary mb-3">← Kembali</a>

    <!-- CARD PENJUALAN -->
    <div class="card card-custom mb-4">
        <div class="card-body">
            <h5 class="mb-3">Informasi Penjualan</h5>

            <div class="row mb-2">
                <div class="col-4">Tanggal</div>
                <div class="col-8 fw-semibold"><?= $penjualan['CREATED_AT']; ?></div>
            </div>

            <div class="row mb-2">
                <div class="col-4">User</div>
                <div class="col-8 fw-semibold"><?= $penjualan['USERNAME']; ?></div>
            </div>

            <div class="row mb-2">
                <div class="col-4">Margin</div>
                <div class="col-8 fw-semibold"><?= $penjualan['MARGIN_PERSEN']; ?>%</div>
            </div>
        </div>
    </div>

    <!-- CARD DETAIL BARANG -->
    <div class="card card-custom">
        <div class="card-body">
            <h5 class="mb-3">Barang yang Terjual</h5>

            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Barang</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        foreach ($detail as $d): 
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $d['NAMA_BARANG']; ?></td>
                            <td><?= number_format($d['HARGA_SATUAN']); ?></td>
                            <td><?= $d['JUMLAH']; ?></td>
                            <td><?= number_format($d['SUBTOTAL']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <hr>

            <!-- SUMMARY -->
            <div class="row">
                <div class="col-8 text-end">Subtotal Nilai:</div>
                <div class="col-4 fw-bold"><?= number_format($penjualan['SUBTOTAL_NILAI']); ?></div>

                <div class="col-8 text-end">PPN (11%):</div>
                <div class="col-4 fw-bold"><?= number_format($penjualan['PPN']); ?></div>

                <div class="col-8 text-end">Total Nilai:</div>
                <div class="col-4 fw-bold"><?= number_format($penjualan['TOTAL_NILAI']); ?></div>
            </div>

        </div>
    </div>

</div>
</body>
</html>
