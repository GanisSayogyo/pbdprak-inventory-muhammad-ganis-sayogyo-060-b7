<?php

include "database.php";

$db = new databaseconnection();
$db->get_connection();

$id = $_GET['id'] ?? null;

if (isset($_GET['id'], $_GET['nama'])){
    $nama = $_GET['nama'];

    $query = "UPDATE ROLE SET NAMA_ROLE = '$nama' WHERE ID_ROLE = $id";
    $result = $db->send_query($query);

    if ($result['status'] == "success"){
        header("location: role.php");
        $db->exit_connection();
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CUD Role</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container mt-5">
    <h2 class="mb-4">Edit Data Role</h2>

    <div class="card mb-4">
      <div class="card-header bg-primary text-white">Edit Role</div>
      <div class="card-body">
        <form action="edit_role.php" method="GET">
          <input type="hidden" name="id" value="<?= $_GET['id'] ?? '' ?>">
          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label">Masukkan Nama Role Baru</label>
              <input type="text" name="nama" class="form-control" placeholder="Nama Role">
            </div>
          </div>
          <button type="submit" class="btn btn-success">Edit</button>
        </form>
      </div>
    </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>