<?php
// checkout.php
include "database.php";
$db = new databaseconnection();
$db->get_connection();

$id_user = intval($_POST['id_user'] ?? 0);
if ($id_user <= 0) {
    header("Location: penjualan.php?error=no_user");
    exit;
}

// ambil margin terbaru untuk user (aktif) — fallback ke id_marginpenjualan  NULL jika tidak ada
$marginRes = $db->send_query("SELECT ID_MARGINPENJUALAN, PERSEN FROM margin_penjualan WHERE ID_USER = $id_user AND STATUS = 1 ORDER BY ID_MARGINPENJUALAN DESC LIMIT 1");
$id_margin = null;
if ($marginRes['status']==='success' && count($marginRes['data'])) {
    $id_margin = intval($marginRes['data'][0]['ID_MARGINPENJUALAN']);
}

// 1) Insert header penjualan (subtotal_nilai, ppn, total_nilai diisi nanti oleh triggers or update manually)
$insertHeader = "INSERT INTO penjualan (created_at, subtotal_nilai, ppn, total_nilai, id_user, id_marginpenjualan)
                 VALUES (NOW(), 0, 0, 0, $id_user, " . ($id_margin!==null ? $id_margin : "NULL") . ")";
$db->send_query($insertHeader);
$id_penjualan = $db->get_last_insert_id();

// 2) Ambil semua keranjang milik user
$k = $db->send_query("SELECT k.*, b.harga FROM keranjang_penjualan k JOIN barang b ON k.id_barang = b.id_barang WHERE k.id_user = $id_user");

if ($k['status'] === 'success' && count($k['data'])>0) {
    foreach($k['data'] as $item) {
        $id_barang = intval($item['id_barang']);
        $jumlah = intval($item['jumlah']);
        // harga diambil dari barang (atau gunakan $item['harga'])
        $harga = intval($item['harga']);
        $subtotal = $harga * $jumlah;

        // insert ke detail_penjualan (triggers akan mengatur harga/subtotal bila diperlukan)
        $sql = "INSERT INTO detail_penjualan (harga_satuan, jumlah, subtotal, id_penjualan, id_barang)
                VALUES ($harga, $jumlah, $subtotal, $id_penjualan, $id_barang)";
        $db->send_query($sql);
    }

    // 3) Recalc totals (jika triggers tidak mengisi penjualan otomatis)
    $sumRes = $db->send_query("SELECT IFNULL(SUM(subtotal),0) AS total_sub FROM detail_penjualan WHERE id_penjualan = $id_penjualan");
    $total_sub = ($sumRes['status']==='success' && count($sumRes['data'])) ? floatval($sumRes['data'][0]['total_sub']) : 0;
    $ppn = $total_sub * 0.11;
    $total_all = $total_sub + $ppn;

    $db->send_query("UPDATE penjualan SET subtotal_nilai = $total_sub, ppn = $ppn, total_nilai = $total_all WHERE id_penjualan = $id_penjualan");

    // 4) Hapus keranjang user
    $db->send_query("DELETE FROM keranjang_penjualan WHERE id_user = $id_user");

    $db->exit_connection();
    header("Location: penjualan.php?user=$id_user&checkout=ok");
    exit;
} else {
    // tidak ada item di keranjang
    $db->send_query("DELETE FROM penjualan WHERE id_penjualan = $id_penjualan"); // rollback header
    $db->exit_connection();
    header("Location: penjualan.php?user=$id_user&error=empty");
    exit;
}
