<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory</title>
    <style>
        /* RESET */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            background: #0a0a0a; /* Dark elegant background */
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
        }

        /* ABSTRACT SOFT WAVES */
        .wave {
            position: absolute;
            width: 160%;
            height: 160%;
            opacity: 0.4;
            background: radial-gradient(circle at 70% 30%, #8f8f8f, transparent 60%),
                        radial-gradient(circle at 20% 80%, #bcbcbc, transparent 65%);
            animation: rotate 24s infinite linear;
            filter: blur(120px);
            mix-blend-mode: screen;
        }

        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .container {
            text-align: center;
            z-index: 10;
        }

        h1 {
            font-size: 3.4rem;
            margin-bottom: 22px;
            font-weight: 600;
            letter-spacing: 1px;
            background: linear-gradient(90deg, #e6e6e6, #7d7d7d);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .btn-login {
            padding: 14px 42px;
            background: linear-gradient(135deg, #4b4b4b, #8f8f8f);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 0 20px rgba(255,255,255,0.12);
        }

        .btn-login:hover {
            transform: scale(1.05);
            box-shadow: 0 0 28px rgba(255,255,255,0.28);
        }

    </style>
</head>
<body>

    <div class="wave"></div>

    <div class="container">
        <h1>Inventory</h1>
        <a href="login.php" class="btn-login">Login</a>
    </div>

</body>
</html>
