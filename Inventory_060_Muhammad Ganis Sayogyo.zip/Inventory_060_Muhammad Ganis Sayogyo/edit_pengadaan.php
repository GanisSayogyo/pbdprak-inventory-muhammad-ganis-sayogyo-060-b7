<?php
include "database.php";

$db = new databaseconnection();
$db->get_connection();

// --- Ambil ID ---
if (!isset($_GET['id'])) {
    die("ID tidak ditemukan.");
}
$id = $db->escape_string($_GET['id']);

// --- Ambil Data Pengadaan ---
$q = "SELECT * FROM PENGADAAN WHERE ID_PENGADAAN = '$id'";
$res = $db->send_query($q);

if ($res['status'] !== "success" || count($res['data']) == 0) {
    die("Data pengadaan tidak ditemukan.");
}

$data = $res['data'][0];

// --- Proses Update ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $vendor = $db->escape_string($_POST['vendor']);
    $total  = $db->escape_string($_POST['total']);

    $update = "
        UPDATE PENGADAAN
        SET ID_VENDOR = '$vendor', TOTAL = '$total'
        WHERE ID_PENGADAAN = '$id'
    ";

    $up = $db->send_query($update);

    if ($up['status'] === "success") {
        header("Location: pengadaan.php");
        exit;
    } else {
        echo "Gagal update pengadaan: " . $up['message'];
    }
}

$db->exit_connection();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Pengadaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-body">
            <h3>Edit Pengadaan</h3>
            <form method="POST">

                <div class="mb-3">
                    <label class="form-label">ID Vendor</label>
                    <input type="number" name="vendor" class="form-control"
                        value="<?= htmlspecialchars($data['ID_VENDOR'] ?? '') ?>"
                        required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Total</label>
                    <input type="number" name="total" class="form-control"
                        value="<?= htmlspecialchars($data['TOTAL'] ?? '') ?>"
                        required>
                </div>


                <button class="btn btn-primary">Simpan</button>
                <a href="pengadaan.php" class="btn btn-secondary">Batal</a>

            </form>
        </div>
    </div>
</div>

</body>
</html>
