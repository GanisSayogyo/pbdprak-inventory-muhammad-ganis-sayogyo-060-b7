<?php
// keranjang_action.php
include "database.php";
$db = new databaseconnection();
$db->get_connection();

$action = $_POST['action'] ?? $_GET['action'] ?? '';
if ($action === 'add') {
    $id_user = intval($_POST['id_user']);
    $id_barang = intval($_POST['id_barang']);
    $jumlah = intval($_POST['jumlah']);

    if ($id_user <=0 || $id_barang <=0 || $jumlah <=0) {
        header("Location: penjualan.php?user=$id_user&error=invalid");
        exit;
    }

    // jika barang sudah di keranjang untuk user yang sama, tambahkan jumlah
    $check = $db->send_query("SELECT id_keranjang, jumlah FROM keranjang_penjualan WHERE id_user=$id_user AND id_barang=$id_barang");
    if ($check['status']==='success' && count($check['data'])>0) {
        $row = $check['data'][0];
        $newjumlah = intval($row['jumlah']) + $jumlah;
        $db->send_query("UPDATE keranjang_penjualan SET jumlah=$newjumlah WHERE id_keranjang=".$row['id_keranjang']);
    } else {
        $db->send_query("INSERT INTO keranjang_penjualan (id_user, id_barang, jumlah) VALUES ($id_user, $id_barang, $jumlah)");
    }

    header("Location: penjualan.php?user=$id_user");
    exit;
}

if ($action === 'remove') {
    $id_keranjang = intval($_POST['id_keranjang']);
    // ambil user agar redirect tepat
    $res = $db->send_query("SELECT id_user FROM keranjang_penjualan WHERE id_keranjang = $id_keranjang");
    $user = $res['status']==='success' && count($res['data']) ? $res['data'][0]['id_user'] : 0;
    $db->send_query("DELETE FROM keranjang_penjualan WHERE id_keranjang = $id_keranjang");
    header("Location: penjualan.php?user=$user");
    exit;
}

if (($action === 'clear') || (isset($_GET['action']) && $_GET['action']==='clear')) {
    $user = intval($_GET['user'] ?? $_POST['user'] ?? 0);
    if ($user>0) $db->send_query("DELETE FROM keranjang_penjualan WHERE id_user = $user");
    header("Location: penjualan.php?user=$user");
    exit;
}

// default
header("Location: penjualan.php");
exit;
