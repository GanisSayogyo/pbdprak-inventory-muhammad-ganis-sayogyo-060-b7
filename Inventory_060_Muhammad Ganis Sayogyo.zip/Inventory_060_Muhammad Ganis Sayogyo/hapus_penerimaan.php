<?php
include "database.php";

if (!isset($_GET['id'])) {
    header("Location: penerimaan.php");
    exit;
}

$id = intval($_GET['id']);

$db = new databaseconnection();
$db->get_connection();

// Hapus detail dulu
$db->send_query("DELETE FROM DETAIL_PENERIMAAN WHERE ID_PENERIMAAN = $id");

// Hapus header penerimaan
$db->send_query("DELETE FROM PENERIMAAN WHERE ID_PENERIMAAN = $id");

$db->exit_connection();

header("Location: penerimaan.php");
exit;
