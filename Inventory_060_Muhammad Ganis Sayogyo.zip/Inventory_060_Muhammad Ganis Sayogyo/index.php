<?php
include "database.php";
include "session_check.php";

$db = new databaseconnection();
$db->get_connection();

// QUERY JUMLAH DATA
$total_pengadaan   = $db->send_query("SELECT COUNT(*) AS total FROM PENGADAAN")['data'][0]['total'] ?? 0;
$total_penerimaan  = $db->send_query("SELECT COUNT(*) AS total FROM PENERIMAAN")['data'][0]['total'] ?? 0;
$total_penjualan   = $db->send_query("SELECT COUNT(*) AS total FROM PENJUALAN")['data'][0]['total'] ?? 0;

// JUMLAH STOK
$query_stok = "SELECT IFNULL(SUM(STOCK), 0) AS total FROM V_STOK_BARANG";
$result_stok = $db->send_query($query_stok);
if ($result_stok['status'] == "error") {
    $query_stok = "SELECT IFNULL(SUM(STOCK), 0) AS total FROM KARTU_STOK";
    $result_stok = $db->send_query($query_stok);
}
$total_stok = $result_stok['data'][0]['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Inventory</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>
    body {
      margin: 0;
      font-family: "Poppins", sans-serif;
      display: flex;
      height: 100vh;
      background-color: #f7f9fc;
      color: #222;
    }

    /* Sidebar */
    .sidebar {
      width: 250px;
      background: #212529;
      color: #eee;
      display: flex;
      flex-direction: column;
      box-shadow: 4px 0 15px rgba(0,0,0,0.3);
    }
    .sidebar h3 {
      padding: 20px;
      font-size: 1.25rem;
      text-align: center;
      background: #343a40;
      border-bottom: 1px solid #4a4a4a;
      color: #fff;
    }
    .sidebar a {
      color: #ccc;
      text-decoration: none;
      padding: 14px 24px;
      display: block;
      transition: 0.25s;
    }
    .sidebar a:hover {
      background: #495057;
      color: #fff;
    }

    /* Main content */
    .main-content {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }

    .navbar-custom {
      background: #ffffff;
      border-bottom: 1px solid #ddd;
      padding: 14px 25px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .user-menu {
      display: flex;
      align-items: center;
      gap: 12px;
      font-weight: 600;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: #343a40;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
      font-size: 18px;
      font-weight: bold;
    }

    .dashboard-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
      gap: 1.3rem;
    }
    .card {
      border: none;
      border-radius: 14px;
      background: #fff;
      padding: 22px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.12);
      transition: 0.3s;
    }
    .card:hover { transform: translateY(-5px); }

    footer {
      padding: 14px;
      text-align: center;
      background: #f1f1f1;
      border-top: 1px solid #ddd;
    }
  </style>
</head>

<body>

  <div class="sidebar">
    <h3>📦 INVENTORY</h3>
    <a href="index.php">🏠 Dashboard</a>
    <a href="barang.php">📋 Barang</a>
    <a href="satuan.php">⚖️ Satuan</a>
    <a href="vendor.php">🏢 Vendor</a>
    <a href="role.php">👤 Role</a>
    <a href="pengadaan.php">📦 Pengadaan</a>
    <a href="penjualan.php">💰 Penjualan</a>
    <a href="kartustok.php">🧾 Kartu Stok</a>
    <a href="marginpenjualan.php">💹 Margin Penjualan</a>
  </div>

  <div class="main-content">
    <!-- NAVBAR USER DROPDOWN -->
    <div class="navbar-custom">
      <span class="fw-bold fs-5">Dashboard Inventory</span>

      <div class="dropdown">
        <div class="user-menu dropdown-toggle" data-bs-toggle="dropdown">
          <div class="user-avatar">
            <?= strtoupper(substr($_SESSION['username'], 0, 1)) ?>
          </div>
          <div class="text-end">
            <?= $_SESSION['username'] ?>
            <br>
            <small class="text-muted"><?= $_SESSION['role'] ?></small>
          </div>
        </div>

        <ul class="dropdown-menu dropdown-menu-end shadow">
          <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </div>

    <div class="container">
      <h4 class="mb-4 fw-semibold">Ringkasan Data</h4>

      <div class="dashboard-cards">
        <div class="card"><h6>Pengadaan</h6><p class="fs-2 fw-bold"><?= $total_pengadaan ?></p></div>
        <div class="card"><h6>Penerimaan</h6><p class="fs-2 fw-bold"><?= $total_penerimaan ?></p></div>
        <div class="card"><h6>Penjualan</h6><p class="fs-2 fw-bold"><?= $total_penjualan ?></p></div>
        <div class="card"><h6>Total Stok</h6><p class="fs-2 fw-bold"><?= $total_stok ?></p></div>
      </div>

      <hr class="my-4">

      <h5>Grafik Statistik Transaksi</h5>
      <canvas id="chartBarang" height="120"></canvas>
    </div>

    <footer>© <?= date("Y") ?> Sistem Inventory</footer>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
new Chart(document.getElementById('chartBarang'), {
  type: 'line',
  data: {
    labels: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun"],
    datasets: [{
      label: "Transaksi",
      data: [3, 5, 2, 8, 6, 9],
      borderWidth: 3,
      fill: false
    }]
  }
});
</script>

</body>
</html>
