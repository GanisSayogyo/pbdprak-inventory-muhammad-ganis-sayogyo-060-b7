<?php
include "database.php";

$db = new databaseconnection();
$db->get_connection();

// proses insert
$insertError = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nama_role'])) {
        $nama_raw = $_POST['nama_role'];
        $nama = trim($db->escape_string($nama_raw));

        if ($nama === "") {
            $insertError = "Nama role tidak boleh kosong.";
        } else {
            $insert = "INSERT INTO ROLE (NAMA_ROLE) VALUES ('$nama')";
            $res = $db->send_query($insert);

            if ($res['status'] === 'success') {
                header("Location: role.php");
                exit;
            } else {
                $insertError = "Gagal menambahkan role: " . $res['message'];
            }
        }
    }
}

// Ambil data role
$query = "SELECT * FROM ROLE ORDER BY ID_ROLE ASC";
$result = $db->send_query($query);
$rows = $result['data'] ?? [];

$db->exit_connection();
?>

<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Manajemen Role — Elegan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    :root{
      --bg: #efefef;
      --card: #f6f6f6;
      --muted: #6c757d;
      --accent: #6c6f73;
    }
    body { background: var(--bg); color:#222; font-family:"Inter", system-ui, -apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial; }
    .card-custom{ background:var(--card); border:0; box-shadow:0 6px 18px rgba(21,24,28,0.06); border-radius:12px; }
    .table thead th { background:transparent; color:var(--accent); border-bottom:2px solid rgba(0,0,0,0.06); }
    .form-label { color:var(--muted); font-weight:600; font-size:.9rem; }
    .btn-primary { background:#5f6366; border-color:#5f6366; }
    .btn-primary:hover { background:#4f5153; border-color:#4f5153; }
    .small-muted { color:var(--muted); font-size:.9rem; }
    footer { margin-top:32px; color:var(--muted); font-size:.9rem; text-align:center; }
  </style>
</head>

<body>

<div class="container py-5">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h1 class="page-title mb-0">Manajemen Role</h1>
      <div class="small-muted">Kelola daftar role pengguna</div>
    </div>
    <a href="index.php" class="btn btn-outline-secondary">Back Home</a>
  </div>

  <!-- Form Tambah Role -->
  <div class="card card-custom mb-4">
    <div class="card-body">
      <h5 class="mb-3">Tambah Role</h5>

      <?php if ($insertError): ?>
        <div class="alert alert-danger py-2"><?php echo htmlspecialchars($insertError); ?></div>
      <?php endif; ?>

      <form action="role.php" method="POST">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Nama Role</label>
            <input type="text" name="nama_role" class="form-control" placeholder="Misal: Admin / Kasir / Manager" required>
          </div>
        </div>

        <div class="mt-3">
          <button type="submit" class="btn btn-primary">Tambah</button>
          <button type="reset" class="btn btn-outline-secondary">Reset</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Tabel Role -->
  <div class="card card-custom">
    <div class="card-body">
      <h5 class="mb-3">Daftar Role</h5>

      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th style="width:10%">ID</th>
              <th>Nama Role</th>
              <th class="text-center" style="width:20%">Aksi</th>
            </tr>
          </thead>

          <tbody>
          <?php if (count($rows) === 0): ?>
            <tr><td colspan="3" class="text-center small-muted py-4">Belum ada data role</td></tr>
          <?php else: ?>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><?php echo htmlspecialchars($r['ID_ROLE']); ?></td>
                <td><?php echo htmlspecialchars($r['NAMA_ROLE']); ?></td>
                <td class="text-center">
                  <a href="edit_role.php?id=<?php echo $r['ID_ROLE']; ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                  <a href="hapus_role.php?id=<?php echo $r['ID_ROLE']; ?>" class="btn btn-sm btn-outline-danger"
                     onclick="return confirm('Yakin ingin menghapus role ini?');">Hapus</a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>

  <footer>
    &copy; <?php echo date('Y'); ?> Inventory System — Tema: Abu-abu Elegan
  </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
