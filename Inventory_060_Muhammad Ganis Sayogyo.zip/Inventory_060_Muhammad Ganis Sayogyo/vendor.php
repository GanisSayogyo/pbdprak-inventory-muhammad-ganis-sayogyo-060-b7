<?php
include "database.php";

$db = new databaseconnection();
$db->get_connection();

// ================= TOGGLE STATUS =================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
    $id_vendor   = (int)$_POST['id_vendor'];
    $status_baru = (int)$_POST['status_baru'];

    $db->send_query("
        UPDATE VENDOR
        SET STATUS = $status_baru
        WHERE ID_VENDOR = $id_vendor
    ");

    header("Location: vendor.php");
    exit;
}

// ================= INSERT VENDOR =================
$insertError = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nama'])) {

    $nama   = trim($db->escape_string($_POST['nama']));
    $badan  = trim($db->escape_string($_POST['badan_hukum']));
    $status = (int)$_POST['status'];

    if ($nama === '' || $badan === '') {
        $insertError = "Nama vendor dan badan hukum wajib diisi.";
    } else {
        $insert = "
            INSERT INTO VENDOR (NAMA_VENDOR, BADAN_HUKUM, STATUS)
            VALUES ('$nama', '$badan', $status)
        ";
        $res = $db->send_query($insert);

        if ($res['status'] === 'success') {
            header("Location: vendor.php");
            exit;
        } else {
            $insertError = "Gagal menambah vendor.";
        }
    }
}

// ================= GET DATA =================
$result = $db->send_query("SELECT * FROM VENDOR ORDER BY ID_VENDOR ASC");
$rows = $result['data'] ?? [];

$db->exit_connection();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manajemen Vendor</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
:root{
  --bg:#efefef;
  --card:#f6f6f6;
  --muted:#6c757d;
}
body{background:var(--bg);font-family:Inter,system-ui;}
.card-custom{background:var(--card);border:0;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,.06);}
.page-title{font-weight:700;}
.small-muted{color:var(--muted);font-size:.9rem;}
</style>
</head>

<body>
<div class="container py-5">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
  <div>
    <h1 class="page-title mb-0">Manajemen Vendor</h1>
    <div class="small-muted">Tambah, edit, aktifkan & nonaktifkan vendor</div>
  </div>
  <a href="index.php" class="btn btn-outline-secondary">← Back Home</a>
</div>

<!-- FORM TAMBAH -->
<div class="card card-custom mb-4">
  <div class="card-body">
    <h5 class="mb-3">Tambah Vendor</h5>

    <?php if ($insertError): ?>
      <div class="alert alert-danger py-2"><?= htmlspecialchars($insertError); ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="row g-3">
        <div class="col-md-5">
          <label class="form-label">Nama Vendor</label>
          <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="col-md-5">
          <label class="form-label">Badan Hukum</label>
          <input type="text" name="badan_hukum" class="form-control" required>
        </div>
        <div class="col-md-2">
          <label class="form-label">Status</label>
          <select name="status" class="form-control">
            <option value="1">Aktif</option>
            <option value="0">Non Aktif</option>
          </select>
        </div>
      </div>

      <div class="mt-3">
        <button class="btn btn-primary">Tambah</button>
        <button type="reset" class="btn btn-outline-secondary">Reset</button>
      </div>
    </form>
  </div>
</div>

<!-- TABLE -->
<div class="card card-custom">
  <div class="card-body">
    <h5 class="mb-3">Daftar Vendor</h5>

    <div class="table-responsive">
      <table class="table align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>ID</th>
            <th>Nama Vendor</th>
            <th>Badan Hukum</th>
            <th>Status</th>
            <th class="text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>

        <?php if (empty($rows)): ?>
          <tr>
            <td colspan="6" class="text-center small-muted py-4">
              Belum ada data vendor
            </td>
          </tr>
        <?php else: $no=1; foreach ($rows as $v): ?>
          <tr>
            <td><?= $no++; ?></td>
            <td><?= $v['ID_VENDOR']; ?></td>
            <td><?= htmlspecialchars($v['NAMA_VENDOR']); ?></td>
            <td><?= htmlspecialchars($v['BADAN_HUKUM']); ?></td>
            <td>
              <?= $v['STATUS']
                ? '<span class="badge bg-success">Aktif</span>'
                : '<span class="badge bg-secondary">Non Aktif</span>'; ?>
            </td>
            <td class="text-center d-flex justify-content-center gap-1">

              <!-- TOGGLE -->
              <form method="POST">
                <input type="hidden" name="id_vendor" value="<?= $v['ID_VENDOR']; ?>">
                <input type="hidden" name="status_baru" value="<?= $v['STATUS'] ? 0 : 1; ?>">
                <button name="toggle_status"
                        class="btn btn-sm <?= $v['STATUS'] ? 'btn-outline-warning' : 'btn-outline-success'; ?>">
                  <?= $v['STATUS'] ? 'Nonaktifkan' : 'Aktifkan'; ?>
                </button>
              </form>

              <!-- EDIT -->
              <a href="edit_vendor.php?id=<?= $v['ID_VENDOR']; ?>"
                 class="btn btn-sm btn-outline-primary">Edit</a>

              <!-- DELETE -->
              <a href="hapus_vendor.php?id=<?= $v['ID_VENDOR']; ?>"
                 class="btn btn-sm btn-outline-danger"
                 onclick="return confirm('Yakin hapus vendor ini?');">
                 Hapus
              </a>

            </td>
          </tr>
        <?php endforeach; endif; ?>

        </tbody>
      </table>
    </div>
  </div>
</div>

<footer class="text-center small-muted mt-4">
  &copy; <?= date('Y'); ?> Inventory System
</footer>

</div>
</body>
</html>
