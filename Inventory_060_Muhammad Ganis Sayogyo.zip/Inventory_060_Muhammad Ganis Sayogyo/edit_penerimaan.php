<?php
include "database.php";

if (!isset($_GET['id'])) {
    header("Location: penerimaan.php");
    exit;
}

$id = intval($_GET['id']);
$db = new databaseconnection();
$db->get_connection();

// Ambil data header + detail
$header = $db->send_query("SELECT * FROM PENERIMAAN WHERE ID_PENERIMAAN = $id")['data'][0] ?? null;
$detail = $db->send_query("SELECT * FROM DETAIL_PENERIMAAN WHERE ID_PENERIMAAN = $id")['data'][0] ?? null;

if (!$header || !$detail) {
    $db->exit_connection();
    header("Location: penerimaan.php");
    exit;
}

$insertError = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_barang = intval($_POST['id_barang']);
    $jumlah_terima = intval($_POST['jumlah_terima']);
    $harga_satuan = intval($_POST['harga_satuan']);
    $subtotal = $jumlah_terima * $harga_satuan;

    if ($id_barang === 0 || $jumlah_terima <= 0) {
        $insertError = "Harap isi semua field dengan benar.";
    } else {
        // Update detail
        $update_detail = "UPDATE DETAIL_PENERIMAAN 
                          SET ID_BARANG=$id_barang, JUMLAH_TERIMA=$jumlah_terima, 
                              HARGA_SATUAN_TERIMA=$harga_satuan, SUB_TOTAL_TERIMA=$subtotal
                          WHERE ID_PENERIMAAN=$id";
        $db->send_query($update_detail);

        $db->exit_connection();
        header("Location: penerimaan.php");
        exit;
    }
}

// Ambil list barang untuk form
$barang_list = $db->send_query("SELECT ID_BARANG, NAMA, HARGA FROM BARANG")['data'];

$db->exit_connection();
?>

<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Edit Penerimaan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
<h3>Edit Penerimaan #<?= $id ?></h3>

<?php if ($insertError): ?>
<div class="alert alert-danger"><?= htmlspecialchars($insertError); ?></div>
<?php endif; ?>

<form method="POST">
    <div class="mb-3">
        <label>Barang</label>
        <select name="id_barang" class="form-control" required>
            <?php foreach($barang_list as $b): ?>
                <option value="<?= $b['ID_BARANG'] ?>" 
                  data-harga="<?= $b['HARGA'] ?>"
                  <?= $b['ID_BARANG']==$detail['ID_BARANG']?'selected':'' ?>>
                  <?= htmlspecialchars($b['NAMA']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label>Jumlah Terima</label>
        <input type="number" name="jumlah_terima" class="form-control" min="1"
               value="<?= $detail['JUMLAH_TERIMA'] ?>" required>
    </div>
    <input type="hidden" name="harga_satuan" id="harga_satuan" value="<?= $detail['HARGA_SATUAN_TERIMA'] ?>">
    <button class="btn btn-primary">Simpan Perubahan</button>
    <a href="penerimaan.php" class="btn btn-secondary">Batal</a>
</form>

<script>
const selectBarang = document.querySelector('select[name="id_barang"]');
const hargaInput = document.getElementById('harga_satuan');

selectBarang.addEventListener('change', function() {
    const harga = this.options[this.selectedIndex].getAttribute('data-harga');
    hargaInput.value = harga ? harga : 0;
});
</script>

</div>
</body>
</html>
