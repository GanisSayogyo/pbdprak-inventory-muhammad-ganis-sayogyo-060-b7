<?php
// pengadaan.php  (single-file: daftar pengadaan + buat pengadaan + keranjang + checkout)
include "database.php";
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$username = $_SESSION['username'] ?? '';

$db = new databaseconnection();
$db->get_connection();

// -----------------------------------------------------------------------------
// SECTIONS HANDLED:
// - Daftar Pengadaan
// - Buat Pengadaan Baru
// - Keranjang: add item, remove item
// - Checkout + insert kartu stok
// -----------------------------------------------------------------------------

// ambil daftar pengadaan
$penq = $db->send_query("SELECT * FROM V_PENGADAAN");

// dropdown data
$vendorList = $db->send_query("SELECT ID_VENDOR, NAMA_VENDOR FROM VENDOR WHERE STATUS = '1'")['data'] ?? [];
$barangList = $db->send_query("SELECT ID_BARANG, NAMA, HARGA FROM BARANG WHERE STATUS = 1")['data'] ?? [];

$selected_user = $id_user; // otomatis dari session

// -------------------- ACTION HANDLERS --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Buat header pengadaan
    if (isset($_POST['buat_pengadaan'])) {
        $id_vendor = intval($_POST['id_vendor']);

        $sql = "INSERT INTO PENGADAAN (TIMESTAMP, ID_USER, STATUS, ID_VENDOR, SUB_TOTAL_NILAI, PPN, TOTAL_NILAI)
                VALUES (NOW(), $id_user, '0', $id_vendor, 0, 0, 0)";
        $res = $db->send_query($sql);

        if ($res['status'] === 'success') {
            $id_pengadaan = $db->get_last_insert_id();
            header("Location: pengadaan.php?id_pengadaan=$id_pengadaan");
            exit;
        } else {
            $error = "Gagal membuat pengadaan: " . $res['message'];
        }
    }

    // tambah item
    if (isset($_POST['add_item'])) {
        $id_pengadaan = intval($_POST['id_pengadaan']);
        $id_barang = intval($_POST['id_barang']);
        $jumlah = max(1, intval($_POST['jumlah']));

        $row = $db->send_query("SELECT HARGA FROM BARANG WHERE ID_BARANG = $id_barang");
        $harga = intval($row['data'][0]['HARGA'] ?? 0);
        $subtotal = $harga * $jumlah;

        $insert = "INSERT INTO DETAIL_PENGADAAN (HARGA_SATUAN, JUMLAH, SUB_TOTAL, ID_BARANG, ID_PENGADAAN)
                   VALUES ($harga, $jumlah, $subtotal, $id_barang, $id_pengadaan)";
        $db->send_query($insert);

        header("Location: pengadaan.php?id_pengadaan=$id_pengadaan");
        exit;
    }

    // hapus item keranjang
    if (isset($_POST['remove_item'])) {
        $id_detail = intval($_POST['id_detail']);
        $id_pengadaan = intval($_POST['id_pengadaan']);

        $db->send_query("DELETE FROM DETAIL_PENGADAAN WHERE ID_DETAIL_PENGADAAN = $id_detail");

        header("Location: pengadaan.php?id_pengadaan=$id_pengadaan");
        exit;
    }

    // checkout
    if (isset($_POST['checkout'])) {
        $id_pengadaan = intval($_POST['id_pengadaan']);

        $sum = $db->send_query("SELECT total_sub_pengadaan($id_pengadaan) AS total_sub");
        $subtotal = floatval($sum['data'][0]['total_sub']);
        $ppn = $subtotal * 0.11;
        $total = $subtotal + $ppn;

        $db->send_query("UPDATE PENGADAAN
                         SET SUB_TOTAL_NILAI = $subtotal, PPN = $ppn, TOTAL_NILAI = $total, STATUS = '1'
                         WHERE ID_PENGADAAN = $id_pengadaan");

        header("Location: pengadaan.php");
        exit;
    }
}

// ambil keranjang
$detail_pengadaan = [];
if (isset($_GET['id_pengadaan'])) {
    $id_pengadaan = intval($_GET['id_pengadaan']);

    $dp = $db->send_query("
        SELECT dp.*, b.NAMA AS NAMA_BARANG
        FROM DETAIL_PENGADAAN dp
        JOIN BARANG b ON dp.ID_BARANG = b.ID_BARANG
        WHERE dp.ID_PENGADAAN = $id_pengadaan
        ORDER BY dp.ID_DETAIL_PENGADAAN ASC
    ");

    if ($dp['status'] === 'success') $detail_pengadaan = $dp['data'];
} else {
    $id_pengadaan = 0;
}

$db->exit_connection();
?>

<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Pengadaan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body{background:#ececec;}
  .card-custom{background:#fff;border-radius:12px;box-shadow:0 8px 18px rgba(0,0,0,.08);}
</style>
</head>
<body>

<div class="container py-5">

  <!-- HEADER DENGAN BACK BUTTON -->
  <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="mb-0 fw-bold">Manajemen Pengadaan</h2>
      <a href="index.php" class="btn btn-outline-secondary">Back</a>
  </div>

  <!-- Daftar Pengadaan -->
  <div class="card card-custom mb-4">
    <div class="card-body">
      <h5 class="mb-3">Daftar Pengadaan</h5>
      <table class="table">
        <thead><tr><th>#</th><th>ID</th><th>Tanggal</th><th>Vendor</th><th>User</th><th>Total</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php if ($penq['status'] !== 'success' || count($penq['data'])===0): ?>
            <tr><td colspan="8" class="text-center">Belum ada data</td></tr>
          <?php else: $no=1; foreach($penq['data'] as $p): ?>
          <tr>
            <td><?= $no++; ?></td>
            <td><?= $p['ID_PENGADAAN']; ?></td>
            <td><?= $p['TIMESTAMP']; ?></td>
            <td><?= $p['NAMA_VENDOR']; ?></td>
            <td><?= $p['USERNAME']; ?></td>
            <td><?= number_format($p['TOTAL_NILAI']); ?></td>
            <td><?= $p['STATUS']=='1'?'Selesai':'Draft'; ?></td>
            <td>
              <a href="pengadaan.php?id_pengadaan=<?= $p['ID_PENGADAAN']; ?>" class="btn btn-sm btn-outline-primary">Detail</a>
              <a href="penerimaan.php?id_pengadaan=<?= $p['ID_PENGADAAN']; ?>" class="btn btn-sm btn-success mt-1">Penerimaan</a>
            </td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- FORM + KERANJANG -->
  <div class="row">
    <div class="col-md-6">
      <div class="card card-custom mb-4"><div class="card-body">
        <h5>Buat Pengadaan</h5>
        <form method="POST">
          <label>User</label>
          <input type="text" class="form-control mb-2" value="<?= htmlspecialchars($username); ?>" disabled>
          <input type="hidden" name="id_user" value="<?= $id_user; ?>">

          <label>Vendor</label>
          <select name="id_vendor" class="form-control mb-2" required>
            <option value="">--Pilih Vendor--</option>
            <?php foreach($vendorList as $v): ?>
            <option value="<?= $v['ID_VENDOR']; ?>"><?= $v['NAMA_VENDOR']; ?></option>
            <?php endforeach; ?>
          </select>

          <button name="buat_pengadaan" class="btn btn-primary">Buat</button>
        </form>
      </div></div>
    </div>

    <!-- Keranjang -->
    <div class="col-md-6">
      <div class="card card-custom mb-4"><div class="card-body">
        <h5>Keranjang Pengadaan (ID: <?= $id_pengadaan ?: '-'; ?>)</h5>

        <?php if ($id_pengadaan == 0): ?>
          <div>Silakan buat header pengadaan dahulu</div>
        <?php else: ?>
        <form method="POST" class="row g-2 mb-3">
          <input type="hidden" name="id_pengadaan" value="<?= $id_pengadaan; ?>">

          <div class="col-8">
            <select name="id_barang" class="form-control" required>
              <option value="">--Pilih Barang--</option>
              <?php foreach($barangList as $b): ?>
              <option value="<?= $b['ID_BARANG']; ?>"><?= $b['NAMA'].' ('.number_format($b['HARGA']).')'; ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-2"><input type="number" name="jumlah" class="form-control" value="1" min="1"></div>
          <div class="col-2"><button name="add_item" class="btn btn-primary w-100">Add</button></div>
        </form>

        <table class="table table-sm">
          <thead><tr><th>#</th><th>Barang</th><th>Harga</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead>
          <tbody>
          <?php if(empty($detail_pengadaan)): ?>
            <tr><td colspan="6" class="text-center">Keranjang Kosong</td></tr>
          <?php else: $i=1; $total=0; foreach($detail_pengadaan as $d): $sub=$d['SUB_TOTAL']; $total+=$sub; ?>
            <tr>
              <td><?= $i++; ?></td>
              <td><?= $d['NAMA_BARANG']; ?></td>
              <td><?= number_format($d['HARGA_SATUAN']); ?></td>
              <td><?= $d['JUMLAH']; ?></td>
              <td><?= number_format($sub); ?></td>
              <td>
                <form method="POST">
                  <input type="hidden" name="id_pengadaan" value="<?= $id_pengadaan; ?>">
                  <input type="hidden" name="id_detail" value="<?= $d['ID_DETAIL_PENGADAAN']; ?>">
                  <button name="remove_item" class="btn btn-sm btn-outline-danger">Hapus</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <tr><td colspan="4" class="text-end fw-bold">TOTAL</td><td><b><?= number_format($total); ?></b></td><td></td></tr>
          <?php endif; ?>
          </tbody>
        </table>

        <form method="POST">
          <input type="hidden" name="id_pengadaan" value="<?= $id_pengadaan; ?>">
          <button name="checkout" class="btn btn-success">Checkout</button>
          <a href="pengadaan.php" class="btn btn-secondary">Batal</a>
        </form>

        <?php endif; ?>
      </div></div>
    </div>
  </div>
</div>
</body>
</html>
