<?php

include "database.php";

$db = new databaseconnection();
$db->get_connection();

$id = $_GET['id'] ?? null;

if (isset($_GET['id'], $_GET['nama'], $_GET['badan_hukum'], $_GET['status'])){
    $nama = $_GET['nama'];
    $status = $_GET['status'];
    $badan_hukum = $_GET['badan_hukum'];

    $query = "UPDATE VENDOR SET NAMA_VENDOR = '$nama', BADAN_HUKUM = '$badan_hukum', STATUS = $status WHERE ID_VENDOR = $id";
    $result = $db->send_query($query);

    if ($result['status'] == "success"){
        header("location: vendor.php");
        $db->exit_connection();
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CUD Vendor</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container mt-5">
    <h2 class="mb-4">Edit Data Vendor</h2>

    <div class="card mb-4">
      <div class="card-header bg-primary text-white">Edit Vendor</div>
      <div class="card-body">
        <form action="edit_vendor.php" method="GET">
          <input type="hidden" name="id" value="<?= $_GET['id'] ?? '' ?>">
          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label">Masukkan Nama Vendor Baru</label>
              <input type="text" name="nama" class="form-control" placeholder="Nama Vendor">
            </div>
            <div class="col-md-6">
              <label class="form-label">Masukkan Badan Hukum Baru</label>
              <input type="text" name="badan_hukum" class="form-control" placeholder="Badan Hukum">
            </div>
            <div class="col-md-3">
              <label class="form-label">Masukkan Status</label>
              <input type="text" name="status" class="form-control" placeholder="Status">
            </div>
          </div>
          <button type="submit" class="btn btn-success">Edit</button>
        </form>
      </div>
    </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>