<?php
// ================== SETUP ==================
session_start();
require_once "database.php";

// wajib supaya try-catch mysqli jalan
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$id_user  = (int)$_SESSION['id_user'];
$username = $_SESSION['username'] ?? '';

// ================== DB ==================
$db = new databaseconnection();
$db->get_connection();

// ================== HANDLE POST ==================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ===== TAMBAH MARGIN =====
    if (isset($_POST['tambah_margin'])) {
        $persen = (float)($_POST['persen'] ?? 0);

        if ($persen > 0) {
            $db->send_query("
                INSERT INTO MARGIN_PENJUALAN (PERSEN, STATUS, ID_USER)
                VALUES ($persen, 1, $id_user)
            ");
        }

        header("Location: marginpenjualan.php");
        exit;
    }

    // ===== TOGGLE STATUS =====
    if (isset($_POST['toggle_status'])) {
        $id_margin = (int)$_POST['id_margin'];

        $q = $db->send_query("
            SELECT STATUS 
            FROM MARGIN_PENJUALAN 
            WHERE ID_MARGINPENJUALAN = $id_margin
        ");

        $current = (int)($q['data'][0]['STATUS'] ?? 0);
        $new     = $current === 1 ? 0 : 1;

        $db->send_query("
            UPDATE MARGIN_PENJUALAN
            SET STATUS = $new
            WHERE ID_MARGINPENJUALAN = $id_margin
        ");

        header("Location: marginpenjualan.php");
        exit;
    }

    // ===== HAPUS MARGIN (PAKAI POPUP) =====
    if (isset($_POST['hapus_margin'])) {
        $id_margin = (int)$_POST['id_margin'];

        try {
            $db->send_query("
                DELETE FROM MARGIN_PENJUALAN
                WHERE ID_MARGINPENJUALAN = $id_margin
            ");

            echo "<script>
                alert('Margin berhasil dihapus');
                window.location='marginpenjualan.php';
            </script>";
            exit;

        } catch (Throwable $e) {

            // foreign key error (dipakai di penjualan)
            if (str_contains($e->getMessage(), 'foreign key constraint fails')) {
                echo "<script>
                    alert('Margin tidak bisa dihapus karena sudah digunakan pada data penjualan.');
                    window.location='marginpenjualan.php';
                </script>";
                exit;
            }

            // error lain
            echo "<script>
                alert('Terjadi kesalahan saat menghapus margin.');
                window.location='marginpenjualan.php';
            </script>";
            exit;
        }
    }
}

// ================== GET DATA ==================
$res = $db->send_query("
    SELECT
        m.ID_MARGINPENJUALAN AS id_marginpenjualan,
        m.PERSEN             AS persen,
        m.STATUS             AS status,
        m.CREATED_AT         AS created_at,
        m.UPDATED_AT         AS updated_at,
        u.USERNAME
    FROM MARGIN_PENJUALAN m
    LEFT JOIN USER u ON m.ID_USER = u.ID_USER
    ORDER BY m.ID_MARGINPENJUALAN DESC
");

$marginList = $res['data'] ?? [];

$db->exit_connection();
?>

<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Manajemen Margin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background:#f4f6f9;
    font-family: system-ui, -apple-system, BlinkMacSystemFont;
}
.card {
    border-radius:12px;
    box-shadow:0 8px 20px rgba(0,0,0,.06);
}
</style>
</head>

<body>
<div class="container py-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center gap-2">
            <a href="index.php" class="btn btn-outline-secondary btn-sm">
                ← Kembali
            </a>
            <h3 class="fw-semibold mb-0">Manajemen Margin Penjualan</h3>
        </div>
        <span class="text-muted">Hai, <?= htmlspecialchars($username); ?></span>
    </div>


    <!-- FORM TAMBAH -->
    <div class="card mb-4">
        <div class="card-body">
            <h6 class="mb-3 fw-semibold">Tambah Margin Baru</h6>

            <form method="POST" class="row g-2">
                <div class="col-md-4">
                    <input type="number" step="0.01" min="0" name="persen"
                           class="form-control" placeholder="Persen (%)" required>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-success w-100" name="tambah_margin">
                        Tambah
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- TABLE -->
    <div class="card">
        <div class="card-body">
            <h6 class="mb-3 fw-semibold">Daftar Margin</h6>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Persen (%)</th>
                            <th>Status</th>
                            <th>User</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($marginList)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">
                                Belum ada data margin
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($marginList as $i => $m): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= number_format($m['persen'], 2) ?></td>
                            <td>
                                <?= $m['status'] == 1
                                    ? '<span class="badge bg-success">Aktif</span>'
                                    : '<span class="badge bg-secondary">Nonaktif</span>'; ?>
                            </td>
                            <td><?= htmlspecialchars($m['USERNAME'] ?? '-') ?></td>
                            <td><?= $m['created_at'] ?></td>
                            <td><?= $m['updated_at'] ?></td>
                            <td class="d-flex gap-1">

                                <form method="POST">
                                    <input type="hidden" name="id_margin"
                                           value="<?= $m['id_marginpenjualan'] ?>">
                                    <button class="btn btn-sm btn-warning"
                                            name="toggle_status">
                                        <?= $m['status'] == 1 ? 'Nonaktifkan' : 'Aktifkan' ?>
                                    </button>
                                </form>

                                <form method="POST"
                                      onsubmit="return confirm('Hapus margin ini?')">
                                    <input type="hidden" name="id_margin"
                                           value="<?= $m['id_marginpenjualan'] ?>">
                                    <button class="btn btn-sm btn-danger"
                                            name="hapus_margin">
                                        Hapus
                                    </button>
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
</body>
</html>
