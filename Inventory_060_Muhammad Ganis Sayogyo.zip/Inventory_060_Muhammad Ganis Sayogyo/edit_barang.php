<?php

include "database.php";

$db = new databaseconnection();
$db->get_connection();

$id = $_GET['id'] ?? null;

if (isset($_GET['id'], $_GET['nama'], $_GET['jenis'], $_GET['harga'], $_GET['satuan'])){
    $nama = $_GET['nama'];
    $jenis = $_GET['jenis'];
    $harga = $_GET['harga'];
    $satuan = $_GET['satuan'];

    $satuan = "SELECT * FROM SATUAN WHERE NAMA_SATUAN = '$satuan'";
    $result_satuan = $db->send_query($satuan);
    $id_satuan = $result_satuan['data'][0]['ID_SATUAN'];


    $query = "UPDATE BARANG SET JENIS = '$jenis', NAMA = '$nama', HARGA = $harga, ID_SATUAN = '$id_satuan' WHERE ID_BARANG = $id";
    $result = $db->send_query($query);

    if ($result['status'] == "success"){
        header("location: barang.php");
        $db->exit_connection();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CUD Barang</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container mt-5">
    <h2 class="mb-4">Manajemen Barang</h2>

    <div class="card mb-4">
      <div class="card-header bg-primary text-white">Edit Barang</div>
      <div class="card-body">
        <form action="edit_barang.php" method="GET">
          <input type="hidden" name="id" value="<?= $_GET['id'] ?? '' ?>">
          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label">Masukkan Nama Baru</label>
              <input type="text" name="nama" class="form-control" placeholder="Masukkan nama barang">
            </div>
            <div class="col-md-3">
              <label class="form-label">Masukkan Jenis baru</label>
              <input type="text" name="jenis" class="form-control" placeholder="Jenis Barang">
            </div>
            <div class="col-md-3">
              <label class="form-label">Masukkan Satuan Barang</label>
              <input type="text" name="satuan" class="form-control" placeholder="Satuan Barang">
            </div>
            <div class="col-md-3">
              <label class="form-label">Masukkan Harga Baru</label>
              <input type="number" name="harga" class="form-control" placeholder="Harga barang">
            </div>
          </div>
          <button type="submit" class="btn btn-success">Edit</button>
        </form>
      </div>
    </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>