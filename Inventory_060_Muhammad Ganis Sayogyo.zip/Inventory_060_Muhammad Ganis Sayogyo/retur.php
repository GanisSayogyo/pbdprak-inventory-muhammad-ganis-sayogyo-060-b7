<?php
include "database.php";

$db = new databaseconnection();
$db->get_connection();

// ambil data dari view retur
$query = "SELECT * FROM V_RETUR_DETAIL";
$hasil = $db->send_query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Retur Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fa;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #dc3545;
            color: white;
        }
        tr:hover {
            background: #f1f1f1;
        }
        h2 {
            color: #333;
        }
    </style>
</head>
<body>
    <h2>Data Retur Barang</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>ID Retur</th>
                <th>Tanggal Retur</th>
                <th>Nama Barang</th>
                <th>Jumlah Retur</th>
                <th>Harga Satuan</th>
                <th>Subtotal Retur</th>
                <th>Nama Vendor</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            foreach($hasil['data'] as $row){
                echo "<tr>";
                echo "<td>{$no}</td>";
                echo "<td>{$row['ID_RETUR']}</td>";
                echo "<td>{$row['CREATED_AT']}</td>";
                echo "<td>{$row['NAMA_BARANG']}</td>";
                echo "<td>{$row['JUMLAH_RETUR']}</td>";
                echo "<td>{$row['HARGA_SATUAN']}</td>";
                echo "<td>{$row['SUB_TOTAL_RETUR']}</td>";
                echo "<td>{$row['NAMA_VENDOR']}</td>";
                echo "<td>{$row['KETERANGAN']}</td>";
                echo "</tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</body>
</html>
