<?php
include "database.php";

$db = new databaseconnection();
$conn = $db->get_connection();

$id = $_GET['id'];

$head = $db->send_query("
    SELECT p.*, v.nama_vendor, u.username
    FROM penerimaan p
    JOIN pengadaan g ON p.id_pengadaan = g.id_pengadaan
    JOIN vendor v ON g.id_vendor = v.id_vendor
    JOIN user u ON p.id_user = u.id_user
    WHERE p.id_penerimaan = $id
")['data'][0];

$detail = $db->send_query("
    SELECT d.*, b.nama
    FROM detail_penerimaan d
    JOIN barang b ON d.id_barang = b.id_barang
    WHERE id_penerimaan = $id
")['data'];

$db->exit_connection();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Detail Penerimaan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5 bg-light">

<div class="container">
  <a href="penerimaan.php" class="btn btn-secondary mb-3">Kembali</a>

  <div class="card mb-4">
    <div class="card-body">
      <h3 class="mb-2">Detail Penerimaan #<?= $id ?></h3>
      <p><b>Vendor:</b> <?= $head['nama_vendor'] ?></p>
      <p><b>User Input:</b> <?= $head['username'] ?></p>
      <p><b>Tanggal:</b> <?= $head['created_at'] ?></p>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <table class="table table-bordered">
        <thead class="table-dark">
          <tr><th>#</th><th>Barang</th><th>Jumlah</th><th>Harga</th><th>Subtotal</th></tr>
        </thead>
        <tbody>
        <?php $no=1; foreach($detail as $d): ?>
          <tr>
            <td><?= $no++; ?></td>
            <td><?= $d['nama']; ?></td>
            <td><?= $d['jumlah_terima']; ?></td>
            <td><?= number_format($d['harga_satuan_terima']); ?></td>
            <td><?= number_format($d['sub_total_terima']); ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

</body>
</html>
