<?php
session_start();
if (isset($_SESSION['username'])) {
  header("Location: index.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Inventory</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
  body{
    background:#0b1220;
    font-family:'Inter',sans-serif;
    height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
  }

  .login-box{
    width:380px;
    background:#111827;
    padding:40px;
    border-radius:14px;
    box-shadow:0 20px 40px rgba(0,0,0,.6);
  }

  .login-title{
    font-size:1.3rem;
    font-weight:700;
    text-align:center;
    margin-bottom:25px;
    color:#e5e7eb;
  }

  .form-label{
    font-size:.85rem;
    color:#9ca3af;
  }

  .form-control{
    background:#1f2937;
    border:1px solid #374151;
    color:#fff;
    padding:12px 14px;
    border-radius:10px;
  }

  .form-control:focus{
    background:#1f2937;
    border-color:#3b82f6;
    box-shadow:0 0 0 .15rem rgba(59,130,246,.35);
    color:#fff;
  }

  .btn-login{
    background:#2563eb;
    border:none;
    border-radius:10px;
    padding:12px;
    font-weight:600;
    transition:.25s;
  }

  .btn-login:hover{
    background:#1d4ed8;
    transform:translateY(-1px);
  }

  .alert{
    font-size:.85rem;
  }

  .footer{
    text-align:center;
    font-size:.75rem;
    margin-top:25px;
    color:#6b7280;
  }
</style>
</head>

<body>

<div class="login-box">
  <div class="login-title">INVENTORY SYSTEM</div>

  <?php if (isset($_GET['error'])): ?>
    <div class="alert alert-danger text-center py-2">
      Username atau password salah
    </div>
  <?php endif; ?>

  <form action="login_process.php" method="POST">
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" name="username" class="form-control" required autofocus>
    </div>

    <div class="mb-4">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-login w-100 text-white">
      LOGIN
    </button>
  </form>

  <div class="footer">
    © <?= date('Y') ?> Inventory Management System
  </div>
</div>

</body>
</html>
