<?php
include "database.php";

$db = new databaseconnection();
$db->get_connection();

// ambil data dari view stok barang
$query = "SELECT * FROM V_STOK_BARANG";
$hasil = $db->send_query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Stok Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fa;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #0d6efd;
            color: white;
        }
        tr:hover {
            background: #f1f1f1;
        }
        h2 {
            color: #333;
        }
    </style>
</head>
<body>
    <h2>Data Stok Barang</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>ID Barang</th>
                <th>Nama Barang</th>
                <th>Satuan</th>
                <th>Stok Masuk</th>
                <th>Stok Keluar</th>
                <th>Stok Akhir</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            foreach($hasil['data'] as $row){
                echo "<tr>";
                echo "<td>{$no}</td>";
                echo "<td>{$row['ID_BARANG']}</td>";
                echo "<td>{$row['NAMA_BARANG']}</td>";
                echo "<td>{$row['SATUAN']}</td>";
                echo "<td>{$row['STOK_MASUK']}</td>";
                echo "<td>{$row['STOK_KELUAR']}</td>";
                echo "<td>{$row['STOK_AKHIR']}</td>";
                echo "</tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</body>
</html>
