<?php

include "database.php";

$db = new databaseconnection();
$db->get_connection();

$id = $_GET['id'] ?? null;

if (isset($_GET['id'])){
    $delete = "DELETE FROM BARANG WHERE ID_BARANG = $id";
    $delete_result = $db->send_query($delete);

    if ($delete_result['status'] == "success"){
        header("location: barang.php");
        $db->exit_connection();
    }
    else {
        echo 'error';
    }
}

?>