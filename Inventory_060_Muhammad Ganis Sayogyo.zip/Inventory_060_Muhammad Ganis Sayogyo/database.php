
<?php 
    
class databaseconnection{
    private string $hostname = "localhost";
    private string $username = "root";
    private string $password = "";
    private string $dbname = "INVENTORY";

    private mysqli $connection;


    public function get_connection(): void {
        $this->connection = new mysqli($this->hostname, $this->username, $this->password, $this->dbname);
    }

    public function send_query(string $query): array {
    $result = $this->connection->query($query);

        if ($this->connection->error){
            return [
                "status" => "error", 
                "message" => $this->connection->error, 
                "data" => []
            ];
        } 
        else if ($result === true){
            return [
                "status" => "success",
                "message" => "query executed successfully",
                "data" => []
            ];
        } 
        else {
            // ambil semua hasil
            $data = $result->fetch_all(MYSQLI_ASSOC);
            $result->close();

            // pastikan semua result dari SP dibersihkan
            while ($this->connection->more_results() && $this->connection->next_result()) {
                $extraResult = $this->connection->use_result();
                if ($extraResult instanceof mysqli_result) $extraResult->close();
            }

            return [
                "status" => "success",
                "message" => "query executed successfully",
                "data" => $data
            ];
        }
    }


    // public function send_query(string $query): array {
    //     $result = $this->connection->query($query);

    //     if ($this->connection->error){
    //         return array
    //         (
    //             "status" => "error", 
    //             "message" => $this->connection->error, 
    //             "data" => []
    //         );
    //     }
    //     else if ($result === true){
    //         return array
    //         (
    //             "status" => "success",
    //             "message" => "query executed successfully",
    //             "data" => []
    //         );
    //     }
    //     else{
    //         return array
    //         (
    //             "status" => "success",
    //             "message" => "query executed successfully",
    //             "data" => $result->fetch_all(MYSQLI_ASSOC)
    //         );
    //     }
    // }

    public function exit_connection(): void{
        if ($this->connection){
            $this->connection->close();
        }
    }

    public function escape_string(string $data): string{
        return $this->connection->real_escape_string($data);
    }

    public function get_last_insert_id(): int {
        return $this->connection->insert_id;
    }
}
        
?>
