<?php
// barang.php (tema abu2 elegan, error-safe)
include "database.php";

$db = new databaseconnection();
$db->get_connection();

// Ambil data barang
$query = "SELECT b.ID_BARANG, b.NAMA, b.JENIS, b.HARGA, s.NAMA_SATUAN
          FROM BARANG b
          LEFT JOIN SATUAN s ON b.ID_SATUAN = s.ID_SATUAN
          ORDER BY b.ID_BARANG ASC";
$result = $db->send_query($query);

// proses insert (ubah jadi POST untuk keamanan)
$insertError = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nama'], $_POST['jenis'], $_POST['harga'], $_POST['satuan'])) {
        $nama_raw = $_POST['nama'];
        $jenis_raw = $_POST['jenis'];
        $harga_raw = $_POST['harga'];
        $satuan_raw = $_POST['satuan'];

        // basic validation
        $nama = trim($db->escape_string($nama_raw));
        $jenis = trim($db->escape_string($jenis_raw));
        $satuan = trim($db->escape_string($satuan_raw));
        $harga = (int)$harga_raw;

        if ($nama === '' || $jenis === '' || $satuan === '' || $harga <= 0) {
            $insertError = "Mohon isi semua field dengan benar (harga > 0).";
        } else {
            // cari satuan
            $qSat = "SELECT ID_SATUAN FROM SATUAN WHERE NAMA_SATUAN = '".$satuan."' LIMIT 1";
            $resSat = $db->send_query($qSat);

            if ($resSat['status'] === 'error') {
                $insertError = "Gagal mencari satuan: " . $resSat['message'];
            } elseif (count($resSat['data']) === 0) {
                $insertError = "Satuan '$satuan' tidak ditemukan. Tambahkan satuan terlebih dahulu.";
            } else {
                $id_satuan = (int)$resSat['data'][0]['ID_SATUAN'];

                $insert = "INSERT INTO BARANG (JENIS, NAMA, ID_SATUAN, STATUS, HARGA)
                           VALUES ('".$jenis."', '".$nama."', ".$id_satuan.", 1, ".$harga.")";
                $resIns = $db->send_query($insert);

                if ($resIns['status'] === 'success') {
                    // redirect agar form tidak double submit
                    header("Location: barang.php");
                    exit;
                } else {
                    $insertError = "Gagal menambah barang: " . $resIns['message'];
                }
            }
        }
    } else {
        $insertError = "Data POST tidak lengkap.";
    }
}

$db->exit_connection();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Manajemen Barang — Elegan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root{
      --bg: #efefef;
      --card: #f6f6f6;
      --muted: #6c757d;
      --accent: #6c6f73;
    }
    body { background: var(--bg); color: #222; font-family: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; }
    .card-custom{ background: var(--card); border: 0; box-shadow: 0 6px 18px rgba(21,24,28,0.06); border-radius: 12px; }
    .table thead th { background: transparent; color: var(--accent); border-bottom: 2px solid rgba(0,0,0,0.06); }
    .form-label { color: var(--muted); font-weight: 600; font-size: .9rem; }
    .btn-primary { background: #5f6366; border-color: #5f6366; }
    .btn-primary:hover { background:#4f5153; border-color:#4f5153; }
    .page-title { color: #2b2d2f; font-weight:700; }
    .small-muted { color: var(--muted); font-size: .9rem; }
    .table tbody tr:hover { background: #fbfbfb; }
    footer { margin-top: 32px; color: var(--muted); font-size: .9rem; text-align:center; }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="page-title mb-0">Manajemen Barang</h1>
        <div class="small-muted">Tambah, edit, dan hapus data barang</div>
      </div>
      <a href="index.php" class="btn btn-outline-secondary">Back Home</a>
    </div>

    <div class="card card-custom mb-4">
      <div class="card-body">
        <h5 class="mb-3">Tambah Barang</h5>

        <?php if ($insertError): ?>
          <div class="alert alert-danger py-2"><?php echo htmlspecialchars($insertError); ?></div>
        <?php endif; ?>

        <form method="POST" action="barang.php">
          <div class="row g-3">
            <div class="col-md-5">
              <label class="form-label">Nama Barang</label>
              <input type="text" name="nama" class="form-control" placeholder="Masukkan nama barang" required>
            </div>
            <div class="col-md-2">
              <label class="form-label">Jenis</label>
              <input type="text" name="jenis" class="form-control" placeholder="A/B/C" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Satuan (ketik nama)</label>
              <input type="text" name="satuan" class="form-control" placeholder="PCS / BOX / KG" required>
              <div class="small-muted mt-1">Pastikan satuan sudah terdaftar di tabel SATUAN.</div>
            </div>
            <div class="col-md-2">
              <label class="form-label">Harga</label>
              <input type="number" name="harga" class="form-control" placeholder="0" min="0" required>
            </div>
          </div>

          <div class="mt-3">
            <button type="submit" class="btn btn-primary">Tambah</button>
            <button type="reset" class="btn btn-outline-secondary">Reset</button>
          </div>
        </form>
      </div>
    </div>

    <div class="card card-custom">
      <div class="card-body">
        <h5 class="mb-3">Daftar Barang</h5>

        <?php
        // Safety checks untuk $result
        $rows = [];
        if (!isset($result) || !is_array($result)) {
            echo "<div class='alert alert-warning'>Gagal mengambil data barang.</div>";
        } elseif ($result['status'] === 'error') {
            echo "<div class='alert alert-danger'>Query error: ".htmlspecialchars($result['message'])."</div>";
        } else {
            $rows = $result['data'] ?? [];
        }
        ?>

        <div class="table-responsive">
          <table class="table align-middle">
            <thead>
              <tr>
                <th style="width:6%">#</th>
                <th>ID</th>
                <th>Nama Barang</th>
                <th>Jenis</th>
                <th>Satuan</th>
                <th class="text-end">Harga</th>
                <th class="text-center">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if (count($rows) === 0): ?>
                <tr><td colspan="7" class="text-center small-muted py-4">Belum ada data barang</td></tr>
              <?php else: ?>
                <?php $no = 1; foreach ($rows as $r): ?>
                  <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($r['ID_BARANG']); ?></td>
                    <td><?php echo htmlspecialchars($r['NAMA']); ?></td>
                    <td><?php echo htmlspecialchars($r['JENIS']); ?></td>
                    <td><?php echo htmlspecialchars($r['NAMA_SATUAN'] ?? '-'); ?></td>
                    <td class="text-end"><?php echo number_format((float)$r['HARGA'],0,',','.'); ?></td>
                    <td class="text-center">
                      <a href="edit_barang.php?id=<?php echo $r['ID_BARANG']; ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                      <a href="hapus_barang.php?id=<?php echo $r['ID_BARANG']; ?>" class="btn btn-sm btn-outline-danger"
                         onclick="return confirm('Yakin hapus barang ini?');">Hapus</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>

    <footer>
      &copy; <?php echo date('Y'); ?> Inventory System — Tema: Abu-abu Elegan
    </footer>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
