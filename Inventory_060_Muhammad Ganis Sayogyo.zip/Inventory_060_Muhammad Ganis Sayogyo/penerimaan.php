<?php
// penerimaan.php
// Tampilan penerimaan (partial receive) — UI seragam dengan pengadaan.php

include "database.php";
session_start();

$db = new databaseconnection();
$db->get_connection();

// require id_pengadaan via GET
if (!isset($_GET['id_pengadaan'])) {
    die("ID Pengadaan tidak ditemukan. Buka dari halaman Pengadaan dan klik 'Terima Barang'.");
}
$id_pengadaan = intval($_GET['id_pengadaan']);

// tentukan id_user: pakai session jika ada, otherwise default 3
$id_user = isset($_SESSION['id_user']) ? intval($_SESSION['id_user']) : 3;

// 1) cek apakah sudah ada penerimaan pending (status 'P') untuk pengadaan ini
$cek = $db->send_query("SELECT * FROM PENERIMAAN WHERE ID_PENGADAAN = $id_pengadaan AND STATUS = 'P'");

if ($cek['status'] === 'success' && count($cek['data']) > 0) {
    $id_penerimaan = intval($cek['data'][0]['ID_PENERIMAAN']);
} else {
    // buat penerimaan baru (status 'P' = pending)
    $ins = $db->send_query("INSERT INTO PENERIMAAN (CREATED_AT, STATUS, ID_PENGADAAN, ID_USER)
                            VALUES (NOW(), 'P', $id_pengadaan, $id_user)");
    if ($ins['status'] !== 'success') {
        die("Gagal membuat penerimaan: " . htmlspecialchars($ins['message']));
    }
    $id_penerimaan = $db->get_last_insert_id();
}

// 2) ambil daftar barang dari DETAIL_PENGADAAN untuk pengadaan ini
$q = "
    SELECT dp.ID_DETAIL_PENGADAAN, dp.ID_BARANG, dp.JUMLAH AS QTY_PESAN, dp.HARGA_SATUAN,
           b.NAMA AS NAMA_BARANG
    FROM DETAIL_PENGADAAN dp
    JOIN BARANG b ON dp.ID_BARANG = b.ID_BARANG
    WHERE dp.ID_PENGADAAN = $id_pengadaan
    ORDER BY dp.ID_DETAIL_PENGADAAN ASC
";
$res = $db->send_query($q);
$barang = [];
if ($res['status'] === 'success') {
    $barang = $res['data'];
} else {
    die("Gagal load detail pengadaan: " . htmlspecialchars($res['message']));
}

// helper: hitung sudah diterima (sum dari DETAIL_PENERIMAAN melalui table PENERIMAAN)
function sudah_diterima_for_pengadaan($db, int $id_pengadaan, int $id_barang): int {
    // panggil stored procedure
    $q = "CALL sp_total_terima($id_pengadaan, $id_barang)";
    $r = $db->send_query($q);

    if ($r['status'] === 'success' && count($r['data'])) {
        return intval($r['data'][0]['total_terima']);
    }

    return 0;
}


// jangan close koneksi; nanti penerimaan_action.php akan bekerja dengan koneksi baru
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Penerimaan Barang — Pengadaan #<?= htmlspecialchars($id_pengadaan); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root{--bg:#efefef;--card:#f6f6f6;--muted:#6c757d;--accent:#6c6f73;}
    body{background:var(--bg);font-family:"Inter",system-ui;}
    .card-custom{background:var(--card);border:0;box-shadow:0 6px 18px rgba(21,24,28,0.06);border-radius:12px;}
    .page-title{font-weight:700;color:#2b2d2f;}
    .small-muted{color:var(--muted);font-size:.9rem;}
    .btn-primary{background:#5f6366;border-color:#5f6366;}
    .btn-primary:hover{background:#4f5153;border-color:#4f5153;}
    .badge-sisa { background:#6c757d; color:#fff; }
    .subtotal-cell { width:140px; }
  </style>
</head>
<body>
<div class="container py-5">

  <!-- HEADER -->
  <div class="d-flex justify-content-between mb-4 align-items-center">
    <div>
      <h1 class="page-title mb-0">Penerimaan Barang</h1>
      <div class="small-muted">Terima barang untuk Pengadaan #<?= htmlspecialchars($id_pengadaan); ?></div>
    </div>
    <a href="pengadaan.php" class="btn btn-outline-secondary">Kembali ke Pengadaan</a>
  </div>

  <!-- CARD: FORM PENERIMAAN -->
  <div class="card card-custom mb-4">
    <div class="card-body">
      <?php if (empty($barang)): ?>
        <div class="alert alert-warning">Tidak ada barang pada pengadaan ini.</div>
      <?php else: ?>
        <form method="POST" action="penerimaan_action.php">
          <input type="hidden" name="id_penerimaan" value="<?= htmlspecialchars($id_penerimaan); ?>">
          <input type="hidden" name="id_pengadaan" value="<?= htmlspecialchars($id_pengadaan); ?>">

          <h5 class="mb-3">Daftar Barang (dari Pengadaan)</h5>

          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>Nama Barang</th>
                  <th>Qty Pesan</th>
                  <th>Sudah Diterima</th>
                  <th>Sisa</th>
                  <th>Terima Sekarang</th>
                  <th>Harga Satuan</th>
                  <th class="text-end">Subtotal Terima</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1; foreach ($barang as $row): 
                    $idb = intval($row['ID_BARANG']);
                    $qty_pesan = intval($row['QTY_PESAN']);
                    $harga_satuan = intval($row['HARGA_SATUAN']);
                    $sudah = sudah_diterima_for_pengadaan($db, $id_pengadaan, $idb);
                    $sisa = max(0, $qty_pesan - $sudah);
                ?>
                  <tr>
                    <td><?= $i++; ?></td>
                    <td><?= htmlspecialchars($row['NAMA_BARANG']); ?></td>
                    <td><?= $qty_pesan; ?></td>
                    <td><?= $sudah; ?></td>
                    <td><span class="badge badge-sisa"><?= $sisa; ?></span></td>

                    <td style="width:150px;">
                      <input 
                        type="number" 
                        name="qty_terima[<?= $idb; ?>]" 
                        class="form-control qty-input" 
                        min="0" 
                        max="<?= $sisa; ?>" 
                        value="0"
                        <?= $sisa === 0 ? "readonly" : ""; ?>
                      >
                    </td>

                    <td><?= number_format($harga_satuan); ?></td>

                    <td class="text-end subtotal-cell">
                      <input type="text" class="form-control subtotal-field text-end" name="subtotal_terima[<?= $idb; ?>]" value="0" readonly>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <!-- footer actions -->
          <div class="d-flex justify-content-between align-items-center mt-3">
            <div class="small-muted">Pastikan input jumlah terima sesuai fisik barang. Partial receive diperbolehkan.</div>
            <div>
              <a href="pengadaan.php" class="btn btn-outline-secondary">Batal</a>
              <button type="submit" class="btn btn-success">Simpan Penerimaan</button>
            </div>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>

</div>

<script>
  // client-side subtotal calculation per row
  document.addEventListener('DOMContentLoaded', function(){
    const rows = document.querySelectorAll('table tbody tr');
    rows.forEach(row => {
      const qtyInput = row.querySelector('.qty-input');
      const hargaCell = row.querySelector('td:nth-child(7)');
      const subtotalField = row.querySelector('.subtotal-field');
      if (!qtyInput || !hargaCell || !subtotalField) return;

      function recalc(){
        const qty = parseInt(qtyInput.value) || 0;
        // angka di cell harga bisa mengandung pemisah ribuan; ambil angka saja
        const hargaText = hargaCell.textContent.replace(/[^0-9\-]/g, '') || '0';
        const harga = parseInt(hargaText, 10) || 0;
        subtotalField.value = (qty * harga).toLocaleString('id-ID');
      }

      qtyInput.addEventListener('input', recalc);
      // inisialisasi
      recalc();
    });
  });
</script>
</body>
</html>
