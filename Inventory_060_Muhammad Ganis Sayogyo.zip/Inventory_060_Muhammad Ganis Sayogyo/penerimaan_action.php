<?php
// penerimaan_action.php
include "database.php";
session_start();

$db = new databaseconnection();
$db->get_connection();

$id_penerimaan = intval($_POST['id_penerimaan']);
$id_pengadaan  = intval($_POST['id_pengadaan']);
$id_user       = isset($_SESSION['id_user']) ? intval($_SESSION['id_user']) : 3;

$qty = $_POST['qty_terima'] ?? [];
$subtotal = $_POST['subtotal_terima'] ?? [];

if (!$id_penerimaan || !$id_pengadaan) {
    die("Parameter tidak lengkap.");
}

$total_sisa = 0;

foreach ($qty as $id_barang => $jumlah) {
    $jumlah = intval($jumlah);
    if ($jumlah <= 0) continue;

    $subClean = str_replace(['.',','], '', $subtotal[$id_barang] ?? "0");
    $subClean = intval($subClean);

    // MASUKKAN KE DETAIL_PENERIMAAN
    $ins = $db->send_query("
        INSERT INTO DETAIL_PENERIMAAN (ID_PENERIMAAN, ID_BARANG, JUMLAH_TERIMA, HARGA_SATUAN_TERIMA, SUB_TOTAL_TERIMA)
        VALUES ($id_penerimaan, $id_barang, $jumlah, $subClean / $jumlah, $subClean)
    ");

    if ($ins['status'] !== 'success') {
        die("Gagal insert detail: " . htmlspecialchars($ins['message']));
    }

    $total_sisa += $jumlah;
}

// CEK APAKAH PENGADAAN SUDAH SELESAI
$cek = $db->send_query("
    SELECT SUM(dp.JUMLAH) AS total_pesan,
           (SELECT IFNULL(SUM(xx.JUMLAH_TERIMA),0)
            FROM DETAIL_PENERIMAAN xx
            JOIN PENERIMAAN pp ON xx.ID_PENERIMAAN = pp.ID_PENERIMAAN
            WHERE pp.ID_PENGADAAN = $id_pengadaan) AS total_terima
    FROM DETAIL_PENGADAAN dp
    WHERE dp.ID_PENGADAAN = $id_pengadaan
");

$tp = intval($cek['data'][0]['total_pesan']);
$tt = intval($cek['data'][0]['total_terima']);

if ($tt >= $tp) {
    $db->send_query("UPDATE PENERIMAAN SET STATUS='C' WHERE ID_PENERIMAAN=$id_penerimaan");
    $db->send_query("UPDATE PENGADAAN SET STATUS='1' WHERE ID_PENGADAAN=$id_pengadaan");
}

// REDIRECT kembali ke pengadaan
header("Location: pengadaan.php?msg=success_receive");
exit;

$db->exit_connection();
?>
